describe('myApp.view1 module', function () {

  beforeEach(module('myApp.view1'));

  describe('view1 controller', function () {

    it('should have a controller', inject(function ($rootScope, $controller) {
      $scope = $rootScope.$new();
      $controller('View1Ctrl', { $scope: $scope });
      expect($scope).toBeDefined();
    }));

    it('should have a method displayJobs to update the jobs', inject(function ($rootScope, $controller) {
      $scope = $rootScope.$new();
      $controller('View1Ctrl', { $scope: $scope });
      let experience = "1";
      let location = "Bengaluru";
      let jobsfeed = [{ title: "UI Developer", companyname: "Alt Tech Solutions", location: "Bengaluru", salary: "8LPA", experience: "1" },
      { title: "Front End Developer", companyname: "Maker Tech Solutions", location: "Chennai", experience: "2" },
      { title: "Hybrid Mobile App Developer", companyname: "Raj Tech Solutions", location: "Bengaluru", experience: "1" },
      { title: "Java Developer", companyname: "Mac Tech Solutions", location: "Mumbai", experience: "1" }];
      let _jobs = [{ title: "UI Developer", companyname: "Alt Tech Solutions", location: "Bengaluru", salary: "8LPA", experience: "1" },
      { title: "Hybrid Mobile App Developer", companyname: "Raj Tech Solutions", location: "Bengaluru", experience: "1" }];
      $scope.displayJobs(jobsfeed, experience, location);
      expect($scope.jobs).toEqual(_jobs);
      expect($scope.numberOfJobs).toEqual(2);
    }));

    it('should have method filter to filter the jobs', inject(function ($rootScope, $controller) {
      $scope = $rootScope.$new();
      $controller('View1Ctrl', { $scope: $scope });
      expect($scope).toBeDefined();
      let experience = "1";
      let location = "Bengaluru";
      let jobsfeed = [{}];
      spyOn($scope, 'displayJobs').and.returnValues([{}]);
      $scope.filter();
      expect($scope.displayJobs).toHaveBeenCalled();
    }));

    it('should have method filterBySkill', inject(function ($rootScope, $controller) {
      $scope = $rootScope.$new();
      $controller('View1Ctrl', { $scope: $scope });
      expect($scope).toBeDefined();
      $scope.skillText = "HTML";
      $scope._jobs = [{ title: "UI Developer", companyname: "Alt Tech Solutions", location: "Bengaluru", salary: "8LPA", experience: "1", skills: "HTML" },
      { title: "Front End Developer", companyname: "Maker Tech Solutions", location: "Chennai", experience: "2", skills: "HTML, CSS3" },
      { title: "Hybrid Mobile App Developer", companyname: "Raj Tech Solutions", location: "Bengaluru", experience: "1", skills: "javascript" },
      { title: "Java Developer", companyname: "Mac Tech Solutions", location: "Mumbai", experience: "1", skills: "CSS3" }];
      $scope.filterBySkill();
      expect($scope.jobs).toEqual([{ title: "UI Developer", companyname: "Alt Tech Solutions", location: "Bengaluru", salary: "8LPA", experience: "1", skills: "HTML" },
      { title: "Front End Developer", companyname: "Maker Tech Solutions", location: "Chennai", experience: "2", skills: "HTML, CSS3" }]);
      expect($scope.numberOfJobs).toEqual(2);
    }));

  });
});