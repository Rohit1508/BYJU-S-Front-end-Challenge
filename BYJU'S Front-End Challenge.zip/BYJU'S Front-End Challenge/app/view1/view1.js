'use strict';

angular.module('myApp.view1', ['ngRoute'])

  .config(['$routeProvider', function($routeProvider) {
    $routeProvider.when('/view1', {
      templateUrl: 'view1/view1.html',
      controller: 'View1Ctrl'
    });
  }])
  .controller('View1Ctrl', ['$scope', '$http', function ($scope, $http) {
    let data; 
    $scope._jobs;
    $scope.skillText = '';
    let _$scope = $scope;
    $scope.fetchApi = () => {
      $http.get('https://api.myjson.com/bins/kez8a').then((response) => {
        data = response.data.jobsfeed;
        _$scope.experience = data.map((ele) => { return ele.experience }).filter((value, index, self) => { return self.indexOf(value.length ? value : angular.noop()) === index });
        _$scope.experience.sort((a, b) => { return a - b });
        _$scope.location = data.map((ele) => { return ele.location }).filter((value, index, self) => { return self.indexOf(value.length ? value : angular.noop()) === index });
        _$scope.selectedExperience = _$scope.experience[0];
        _$scope.selectedLocation = _$scope.location[0];
        _$scope.displayJobs(data, _$scope.experience[0], _$scope.location[0]);

      });
    }

    $scope.displayJobs = (jobsfeed, experience, location) => {
      $scope.jobs = jobsfeed.filter((ele) => { return ele.experience === experience }).filter((ele) => { return ele.location === location });
      $scope.numberOfJobs = $scope.jobs.length;
      $scope._jobs = $scope.jobs;
    }
    $scope.filter = () => {
      $scope.displayJobs(data, $scope.selectedExperience, $scope.selectedLocation);
    }
    $scope.sortByExp = () => {
      $scope.jobs.sort((a, b) => { a.experience - b.experience });
    }
    $scope.filterBySkill = () => {
      let searchedSkill = ($scope.skillText).toLowerCase();
      $scope.jobs = $scope._jobs.filter(function (obj, index) {
        return obj.skills.toLowerCase().indexOf(searchedSkill) !== -1;
      })
      $scope.numberOfJobs = $scope.jobs.length;
    }
  }]);